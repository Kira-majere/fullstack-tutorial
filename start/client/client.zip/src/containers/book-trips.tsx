import React from 'react';

const BookTrips: React.FC<any> = () => {
  return <div/>;
}

export default BookTrips;
