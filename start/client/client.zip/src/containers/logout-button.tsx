import React from 'react';

const LogoutButton: React.FC<any> = () => {
  return <div/>;
}

export default LogoutButton;